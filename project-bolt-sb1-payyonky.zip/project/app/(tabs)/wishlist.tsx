import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Heart, ShoppingBag } from 'lucide-react-native';

const WISHLIST_ITEMS = [
  {
    id: 1,
    name: 'Designer Saree',
    price: '₹7,999',
    image: 'https://images.unsplash.com/photo-1610030469668-8e9f641aeb7a?q=80&w=400&h=500&fit=crop',
  },
  {
    id: 2,
    name: 'Silk Dress Material',
    price: '₹2,499',
    image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=400&h=500&fit=crop',
  },
  {
    id: 3,
    name: 'Party Wear Blouse',
    price: '₹1,299',
    image: 'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=400&h=500&fit=crop',
  },
];

export default function WishlistScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Wishlist</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {WISHLIST_ITEMS.map((item) => (
          <View key={item.id} style={styles.wishlistItem}>
            <Image source={{ uri: item.image }} style={styles.itemImage} />
            <View style={styles.itemInfo}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>{item.price}</Text>
              <View style={styles.actionButtons}>
                <TouchableOpacity style={styles.addToCartButton}>
                  <ShoppingBag size={20} color="#ffffff" />
                  <Text style={styles.addToCartText}>Add to Cart</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.removeButton}>
                  <Heart size={20} color="#D81B60" fill="#D81B60" />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    padding: 20,
    backgroundColor: '#D81B60',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  wishlistItem: {
    flexDirection: 'row',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f1f1',
  },
  itemImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
  },
  itemInfo: {
    flex: 1,
    marginLeft: 16,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333333',
  },
  itemPrice: {
    fontSize: 16,
    color: '#D81B60',
    fontWeight: '600',
    marginTop: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  addToCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D81B60',
    padding: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  addToCartText: {
    color: '#ffffff',
    marginLeft: 8,
    fontWeight: '600',
  },
  removeButton: {
    padding: 8,
    marginLeft: 12,
  },
});