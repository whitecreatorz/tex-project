import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const CATEGORIES = [
  { id: 1, name: 'Sarees', items: [
    'Silk Sarees',
    'Cotton Sarees',
    'Designer Sarees',
    'Party Wear Sarees',
    'Traditional Sarees'
  ]},
  { id: 2, name: 'Dress Materials', items: [
    'Cotton Suits',
    'Silk Suits',
    'Casual Wear',
    'Party Wear',
    'Designer Suits'
  ]},
  { id: 3, name: 'Blouses', items: [
    'Ready-made Blouses',
    'Designer Blouses',
    'Embroidered Blouses',
    'Plain Blouses',
    'Party Wear Blouses'
  ]},
  { id: 4, name: 'Kurtis', items: [
    'Casual Kurtis',
    'Party Wear Kurtis',
    'Designer Kurtis',
    'Cotton Kurtis',
    'Silk Kurtis'
  ]},
];

export default function CategoriesScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Categories</Text>
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {CATEGORIES.map((category) => (
          <View key={category.id} style={styles.categorySection}>
            <Text style={styles.categoryTitle}>{category.name}</Text>
            {category.items.map((item, index) => (
              <TouchableOpacity key={index} style={styles.itemButton}>
                <Text style={styles.itemText}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    padding: 20,
    backgroundColor: '#D81B60',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  categorySection: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f1f1',
  },
  categoryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333333',
  },
  itemButton: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f1f1',
  },
  itemText: {
    fontSize: 16,
    color: '#666666',
  },
});